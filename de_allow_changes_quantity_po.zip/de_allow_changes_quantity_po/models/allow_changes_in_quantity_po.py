# -*- coding: utf-8 -*-
from odoo import models

class ItClusterExt(models.Model):
    _inherit = 'purchase.order'
